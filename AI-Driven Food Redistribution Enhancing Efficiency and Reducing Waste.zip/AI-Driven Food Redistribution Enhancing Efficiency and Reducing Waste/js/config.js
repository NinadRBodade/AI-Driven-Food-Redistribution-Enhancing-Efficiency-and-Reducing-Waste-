var firebaseConfig = {
    apiKey: "AIzaSyBvQUksQ0mYp4uZCgrLrirYdFZ7Q8DjbpU",
  authDomain: "food-donation-a4c8b.firebaseapp.com",
  databaseURL: "https://food-donation-a4c8b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "food-donation-a4c8b",
  storageBucket: "food-donation-a4c8b.firebasestorage.app",
  messagingSenderId: "698632370210",
  appId: "1:698632370210:web:8bbfa0356079903b0cb27b",
  measurementId: "G-L2KM90ZFH7"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
